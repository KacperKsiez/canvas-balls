let circleList = [];

var colorArray = [
	"#61a4ec",
	"#4b97e9",
	"#348ae7",
	"#1d7de4",
	"#56b000",
	"#6fe300",
	"#7cfc00",
	"#89ff17",
];

var canvas = document.querySelector("canvas");
var c = canvas.getContext("2d");

canvas.width = innerWidth;
canvas.height = innerHeight;

function Circle(x, y, radius, dx, dy, min) {
	this.x = x;
	this.y = y;
	this.min = min;

	this.dx = dx;
	this.dy = dy;

	this.radius = radius;
	this.color = colorArray[Math.floor(Math.random() * colorArray.length)];

	this.draw = function () {
		c.beginPath();

		c.fillStyle = this.color;

		c.arc(this.x, this.y, this.radius, 0, 10, false);
		c.stroke();
		c.fill();
	};

	this.update = function () {
		if (this.x + this.radius > innerWidth || this.x - this.radius < 0) {
			this.dx = -this.dx;
		}

		if (this.y + this.radius > innerHeight || this.y - this.radius < 0) {
			this.dy = -this.dy;
		}

		this.x += this.dx;
		this.y += this.dy;

		if (
			mouse.x - this.x < 60 &&
			mouse.x - this.x > -60 &&
			mouse.y - this.y < 60 &&
			mouse.y - this.y > -60
		) {
			if (this.radius > 80) {
				this.radius -= 5;
			}
			this.radius += 5;
		} else if (this.radius > this.min) {
			this.radius -= 5;
		}

		this.draw();
	};

	this.draw();
	console.log("sd");
}
let mainY, mainX;

var mouse = {
	x: undefined,
	y: undefined,
};

window.addEventListener("mousemove", (event) => {
	mouse.x = event.x;
	mouse.y = event.y;
});

window.addEventListener("mouseout", (event) => {
	mouse.x = undefined;
	mouse.y = undefined;
});

function animate() {
	requestAnimationFrame(animate);

	c.clearRect(0, 0, innerWidth, innerHeight);

	for (const circle of circleList) {
		circle.update();
	}

	// let circle = circleList[0];
	// circle.radius = 100;
	// circle.dx = 0;
	// circle.dy = 0;
	// circle.x = 200;
	// circle.y = 200;

	// circle.x = mainX;
	// circle.y = mainY;
}
c.strokeStyle = "blue";
animate();

canvas.addEventListener("mousemove", (el) => {
	mainY = el.clientY;
	mainX = el.clientX;
});

function calcAmount() {
	let x = (innerHeight * innerWidth) / 2200;
	return x;
}

window.addEventListener("resize", () => {
	canvas.width = innerWidth;
	canvas.height = innerHeight;

	init(calcAmount());
});

function init(amount) {
	circleList = [];
	for (let i = 0; i < amount; i++) {
		const X = Math.random() * innerWidth,
			Y = Math.random() * innerHeight,
			radius = Math.random() * 15 + 5,
			dx = Math.random() * 5,
			dy = Math.random() * 5;

		circleList.push(new Circle(X, Y, radius, dx, dy, radius));
	}
	console.log(`number of circles: ${circleList.length}`);
}
init(calcAmount());
